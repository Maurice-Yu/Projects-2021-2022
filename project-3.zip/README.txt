Maurice Yu
i did not attempt extra credit
i am claiming that my get sequence and contains runs o logn

i am claiming that my decode method is o of b
